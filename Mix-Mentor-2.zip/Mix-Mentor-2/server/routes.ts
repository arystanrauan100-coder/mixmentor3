import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.advice.getAdvice.path, async (req, res) => {
    try {
      const input = api.advice.getAdvice.input.parse(req.body);
      const chatId = req.headers["x-chat-id"] as string || "default";
      
      // Get history
      const history = await storage.getMessages(chatId);
      
      const systemPrompt = `Ты элитный звукорежиссер и AI-ментор по сведению и мастерингу мирового уровня.
Тебя зовут MixMentor AI. Твоя специализация — создание коммерческого, дорогого звучания.
Ты знаешь секреты сведения топовых артистов (например, как сделать вокал в стиле Джастина Бибера — яркий, воздушный, плотный и "сидящий" в миксе).

Правила ответов:
1. Отвечай на русском языке.
2. Давай максимально детальные инструкции: цепочки плагинов, конкретные частоты (Hz), настройки компрессии (Attack, Release, Ratio), типы сатурации.
3. Если пользователь спрашивает про конкретного артиста, разбери его характерные фишки (например, многослойный дабл-трекинг, параллельная компрессия, специфический реверб).
4. Форматируй ответ красиво с помощью Markdown (заголовки, жирный текст, списки).
5. Поддерживай диалог, учитывая предыдущие сообщения.`;

      const messagesForAI = [
        { role: "system", content: systemPrompt },
        ...history.map(m => ({ role: m.role, content: m.content })),
        { role: "user", content: input.problem }
      ];

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // Using gpt-4o for complex high-level queries
        messages: messagesForAI as any,
        max_completion_tokens: 2000,
      });

      const advice = response.choices[0]?.message?.content || "Не удалось сгенерировать совет. Попробуйте еще раз.";
      
      // Save messages asynchronously
      storage.saveMessage({ chatId, role: "user", content: input.problem }).catch(console.error);
      storage.saveMessage({ chatId, role: "assistant", content: advice }).catch(console.error);
      
      // Save for analytics silently
      try {
        await storage.saveAdviceRequest({ ...input, advice });
      } catch (e) {
        console.error("Failed to save advice request:", e);
      }

      res.status(200).json({ advice });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0]?.message || "Некорректный ввод",
          field: err.errors[0]?.path.join('.'),
        });
      }
      console.error(err);
      res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });

  return httpServer;
}
