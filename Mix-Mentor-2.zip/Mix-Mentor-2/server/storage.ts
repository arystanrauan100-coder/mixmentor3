import { db } from "./db";
import { adviceRequests, messages, type InsertAdviceRequest, type AdviceRequest, type Message, type InsertMessage } from "@shared/schema";
import { eq, asc } from "drizzle-orm";

export interface IStorage {
  saveAdviceRequest(request: InsertAdviceRequest & { advice: string }): Promise<AdviceRequest>;
  saveMessage(message: InsertMessage): Promise<Message>;
  getMessages(chatId: string): Promise<Message[]>;
}

export class DatabaseStorage implements IStorage {
  async saveAdviceRequest(request: InsertAdviceRequest & { advice: string }): Promise<AdviceRequest> {
    const [saved] = await db.insert(adviceRequests).values(request).returning();
    return saved;
  }

  async saveMessage(message: InsertMessage): Promise<Message> {
    const [saved] = await db.insert(messages).values(message).returning();
    return saved;
  }

  async getMessages(chatId: string): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.chatId, chatId)).orderBy(asc(messages.createdAt));
  }
}

export const storage = new DatabaseStorage();
